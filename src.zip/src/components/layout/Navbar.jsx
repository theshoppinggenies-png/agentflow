export default function Navbar() {
  return (
    <nav className="flex justify-between items-center py-4 px-6 bg-white shadow-sm">
      <h1 className="text-2xl font-bold text-gray-800">AgentFlow</h1>
      <div className="space-x-4">
        <a href="#" className="text-gray-600 hover:text-gray-900">Features</a>
        <a href="#" className="text-gray-600 hover:text-gray-900">Pricing</a>
        <a href="#" className="text-gray-600 hover:text-gray-900">Contact</a>
      </div>
    </nav>
  );
}

