import React, { useState } from "react";


// LeadQualify - Homepage React component
// Single-file, Tailwind CSS utility classes. Drop into a React app that has Tailwind configured.

export default function LeadQualifyHome() {
  const [form, setForm] = useState({ name: "", agency: "", email: "", phone: "", message: "" });
  const [submitted, setSubmitted] = useState(false);

  function handleChange(e) {
    setForm((s) => ({ ...s, [e.target.name]: e.target.value }));
  }

  function handleSubmit(e) {
    e.preventDefault();
    // This is a client-only demo. Replace with your API endpoint when ready.
    console.log("Lead request", form);
    setSubmitted(true);
    setTimeout(() => setSubmitted(false), 4000);
  }

  return (
    <div className="min-h-screen bg-gray-50 text-gray-800">
      <header className="bg-white shadow-sm">
        <div className="max-w-6xl mx-auto px-6 py-5 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-indigo-600 to-sky-400 rounded-full flex items-center justify-center text-white font-bold">LQ</div>
            <div>
              <h1 className="text-lg font-semibold">LeadQualify</h1>
              <p className="text-xs text-gray-500">LeO-sourced • Quote-ready commercial leads</p>
            </div>
          </div>
          <nav className="hidden md:flex gap-6 items-center text-sm text-gray-600">
            <a href="#how" className="hover:text-gray-900">How it works</a>
            <a href="#pricing" className="hover:text-gray-900">Pricing</a>
            <a href="#contact" className="px-4 py-2 bg-indigo-600 text-white rounded-md shadow-sm hover:bg-indigo-700">Request Sample</a>
          </nav>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-6 py-16">
        {/* HERO */}
        <section className="grid grid-cols-1 md:grid-cols-2 gap-10 items-center">
          <div>
            <h2 className="text-3xl md:text-4xl font-extrabold leading-tight">Stop Chasing Cold Leads — Get Quote‑Ready Prospects</h2>
            <p className="mt-4 text-gray-600 leading-relaxed">We call LeO-sourced commercial prospects, verify policy details, confirm renewal dates and carriers, and deliver warm leads that are ready to quote. Spend less time dialing and more time closing.</p>

            <div className="mt-6 flex flex-wrap gap-3">
              <a href="#contact" className="inline-flex items-center gap-2 px-5 py-3 bg-indigo-600 text-white rounded-md shadow hover:bg-indigo-700">Get Qualified Leads</a>
              <a href="#pricing" className="inline-flex items-center gap-2 px-5 py-3 border border-gray-200 rounded-md hover:bg-gray-100">See Pricing</a>
            </div>

            <div className="mt-8 grid grid-cols-2 gap-4">
              <div className="bg-white p-4 rounded-lg shadow-sm">
                <div className="text-xs text-gray-500">Average Lead Close Rate</div>
                <div className="text-xl font-bold">23%</div>
              </div>
              <div className="bg-white p-4 rounded-lg shadow-sm">
                <div className="text-xs text-gray-500">Avg. Time Saved / wk</div>
                <div className="text-xl font-bold">8+ hrs</div>
              </div>
            </div>
          </div>

          <div>
            <div className="bg-white border border-gray-100 p-6 rounded-xl shadow-sm">
              <h3 className="text-lg font-semibold">Lead Preview</h3>
              <p className="text-sm text-gray-500 mt-2">Sample of the data we deliver with each qualified lead.</p>

              <div className="mt-4 space-y-3 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-600">Company</span>
                  <span className="font-medium">PERRY &amp; PERRY BUILDERS INC</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Address</span>
                  <span className="font-medium">215 E CAMERON AVE, ROCKDALE, TX</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Employees</span>
                  <span className="font-medium">100-249</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Workers Comp Renewal</span>
                  <span className="font-medium">01-01-2025 (ACIG)</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Contacts</span>
                  <span className="font-medium">Lin Perry — President — (512) 446-2752</span>
                </div>
              </div>

              <div className="mt-6 text-xs text-gray-500">Leads include: FEIN, NAICS/SIC, OSHA history, DOT/fleet data, class codes, carrier history, contacts, and renewal dates.</div>
            </div>
          </div>
        </section>

        {/* How it works */}
        <section id="how" className="mt-16">
          <div className="text-center max-w-3xl mx-auto">
            <h3 className="text-2xl font-bold">How It Works</h3>
            <p className="mt-3 text-gray-600">We turn LeO data into warm, high-intent opportunities — with a simple 3-step process.</p>
          </div>

          <div className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <div className="text-indigo-600 font-semibold">1. Source</div>
              <h4 className="mt-2 font-semibold">LeO Commercial Data</h4>
              <p className="mt-2 text-sm text-gray-600">We filter LeO by industry, class code and renewal signals to build targeted call lists for your agency.</p>
            </div>

            <div className="bg-white p-6 rounded-lg shadow-sm">
              <div className="text-indigo-600 font-semibold">2. Qualify</div>
              <h4 className="mt-2 font-semibold">Human-Verified Details</h4>
              <p className="mt-2 text-sm text-gray-600">Our US-based callers confirm contacts, policy types, renewal dates, carrier names and request docs when allowed.</p>
            </div>

            <div className="bg-white p-6 rounded-lg shadow-sm">
              <div className="text-indigo-600 font-semibold">3. Deliver</div>
              <h4 className="mt-2 font-semibold">Ready‑to‑Quote Leads</h4>
              <p className="mt-2 text-sm text-gray-600">Receive leads via email, CSV, or direct CRM integration — complete with consent and follow-up windows.</p>
            </div>
          </div>
        </section>

        {/* Benefits */}
        <section className="mt-16 bg-gradient-to-r from-white to-gray-50 p-8 rounded-lg">
          <div className="max-w-4xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h4 className="text-xl font-semibold">Why Agents Choose LeadQualify</h4>
              <ul className="mt-4 space-y-3 text-gray-600">
                <li>• We only charge for qualified leads — no subscription lock-ins.</li>
                <li>• Data powered by LeO — fresh, exportable, and insurance-specific.</li>
                <li>• Dedicated callers trained to gather the exact quoting info you need.</li>
                <li>• Quick integration into your workflow — email, CSV, or direct CRM push.</li>
              </ul>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <h5 className="font-semibold">Trust & Compliance</h5>
              <p className="mt-2 text-sm text-gray-600">All outreach follows TCPA and state regulations. We document permissions and maintain an audit trail for every qualified lead.</p>
              <div className="mt-4 text-sm text-gray-500">We do not sell PII beyond lead delivery and always provide opt-out handling per agent preferences.</div>
            </div>
          </div>
        </section>

        {/* Pricing */}
        <section id="pricing" className="mt-16">
          <div className="text-center">
            <h3 className="text-2xl font-bold">Pricing</h3>
            <p className="mt-2 text-gray-600">Simple, pay‑per‑lead pricing so you only pay for what converts.</p>
          </div>

          <div className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="p-6 bg-white rounded-lg shadow-sm">
              <div className="text-sm text-gray-500">Verified Lead</div>
              <div className="mt-2 text-2xl font-bold">$85</div>
              <p className="mt-2 text-gray-600 text-sm">Contact verified, renewal & carrier details confirmed. Ready to quote.</p>
            </div>

            <div className="p-6 bg-indigo-600 text-white rounded-lg shadow-lg">
              <div className="text-sm opacity-90">Appointment Set</div>
              <div className="mt-2 text-2xl font-bold">$125</div>
              <p className="mt-2 text-sm opacity-90">We set a confirmed appointment or warm transfer for your agent.</p>
            </div>

            <div className="p-6 bg-white rounded-lg shadow-sm">
              <div className="text-sm text-gray-500">Volume Plans</div>
              <div className="mt-2 text-2xl font-bold">Custom</div>
              <p className="mt-2 text-gray-600 text-sm">Contact us for volume pricing and dedicated campaigns.</p>
            </div>
          </div>
        </section>

        {/* Contact */}
        <section id="contact" className="mt-16">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-start">
            <div>
              <h3 className="text-2xl font-bold">Request Sample Leads</h3>
              <p className="mt-3 text-gray-600">Tell us a bit about your agency and target market — we’ll send sample leads you can review before committing.</p>

              <div className="mt-6 bg-white p-6 rounded-lg shadow-sm">
                <h4 className="font-semibold">What we deliver</h4>
                <ul className="mt-3 text-sm text-gray-600 space-y-2">
                  <li>• Full contact info, role & direct phone</li>
                  <li>• Renewal dates & carrier names</li>
                  <li>• FEIN, NAICS/SIC, OSHA history, fleet data</li>
                  <li>• Permission to quote + follow-up window</li>
                </ul>
              </div>
            </div>

            <div>
              <form onSubmit={handleSubmit} className="bg-white p-6 rounded-lg shadow-sm">
                {submitted && <div className="mb-4 text-sm text-green-700">Thanks — sample request received. We will email you shortly.</div>}

                <label className="block text-sm font-medium text-gray-700">Full name</label>
                <input name="name" value={form.name} onChange={handleChange} className="mt-1 block w-full rounded-md border-gray-200 shadow-sm p-2" required />

                <label className="block text-sm font-medium text-gray-700 mt-4">Agency</label>
                <input name="agency" value={form.agency} onChange={handleChange} className="mt-1 block w-full rounded-md border-gray-200 shadow-sm p-2" />

                <label className="block text-sm font-medium text-gray-700 mt-4">Email</label>
                <input name="email" type="email" value={form.email} onChange={handleChange} className="mt-1 block w-full rounded-md border-gray-200 shadow-sm p-2" required />

                <label className="block text-sm font-medium text-gray-700 mt-4">Phone</label>
                <input name="phone" value={form.phone} onChange={handleChange} className="mt-1 block w-full rounded-md border-gray-200 shadow-sm p-2" />

                <label className="block text-sm font-medium text-gray-700 mt-4">Message (target industry / state)</label>
                <textarea name="message" value={form.message} onChange={handleChange} className="mt-1 block w-full rounded-md border-gray-200 shadow-sm p-2" rows={4} />

                <button type="submit" className="mt-4 w-full inline-flex justify-center px-4 py-2 bg-indigo-600 text-white rounded-md">Request Samples</button>
              </form>
            </div>
          </div>
        </section>

        <footer className="mt-16 text-center text-sm text-gray-500">
          © {new Date().getFullYear()} LeadQualify — Data sourced from LeO and public records. All outreach follows TCPA & applicable state laws.
        </footer>
      </main>
    </div>
  );
}
