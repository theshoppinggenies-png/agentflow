export default function App() {
  return (
   <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-700 text-white flex flex-col">
      {/* Header */}
      <header className="bg-gray-950/80 border-b border-gray-800 py-4 px-6 flex justify-between items-center">
        <h1 className="text-xl font-bold tracking-wide text-blue-400">AgentFlow</h1>
        <nav className="space-x-6">
          <a href="#" className="text-gray-300 hover:text-white transition">Dashboard</a>
          <a href="#" className="text-gray-300 hover:text-white transition">Leads</a>
          <a href="#" className="text-gray-300 hover:text-white transition">Settings</a>
        </nav>
      </header>

      {/* Main Section */}
      <main className="flex-1 flex items-center justify-center px-6">
        <div className="bg-gray-800/70 rounded-2xl shadow-xl max-w-3xl w-full p-10 text-center backdrop-blur-md border border-gray-700">
          <h2 className="text-3xl font-semibold mb-4 text-blue-300">
            Welcome to AgentFlow
          </h2>
          <p className="text-gray-300 mb-6">
            This is your clean blue-gray interface — ready for components, data panels, and tools.
          </p>
          <button className="bg-blue-500 hover:bg-blue-600 text-white font-medium px-6 py-3 rounded-xl transition">
            Get Started
          </button>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-gray-950/80 border-t border-gray-800 py-4 text-center text-sm text-gray-500">
        © {new Date().getFullYear()} AgentFlow. All rights reserved.
      </footer>
    </div>
  );
}

